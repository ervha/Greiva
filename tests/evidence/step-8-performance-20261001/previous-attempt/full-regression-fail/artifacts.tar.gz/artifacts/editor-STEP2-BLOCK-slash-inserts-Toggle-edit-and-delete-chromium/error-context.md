# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: editor.spec.ts >> STEP2-BLOCK: slash inserts Toggle, edit and delete
- Location: tests/e2e/editor.spec.ts:26:3

# Error details

```
Error: page.goto: net::ERR_CONNECTION_REFUSED at http://127.0.0.1:1420/?page=b6f64245-29b1-471b-8148-fa3b33b93d78
Call log:
  - navigating to "http://127.0.0.1:1420/?page=b6f64245-29b1-471b-8148-fa3b33b93d78", waiting until "load"

```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | 
  3   | async function body(page: Page) {
> 4   |   await page.goto(`/?page=${crypto.randomUUID()}`);
      |              ^ Error: page.goto: net::ERR_CONNECTION_REFUSED at http://127.0.0.1:1420/?page=b6f64245-29b1-471b-8148-fa3b33b93d78
  5   |   const editor = page.getByRole('textbox', { name: 'Page本文' });
  6   |   // This is interaction setup, not the release startup performance gate.
  7   |   await expect(editor).toBeVisible({ timeout: 15000 });
  8   |   await editor.click();
  9   |   return editor;
  10  | }
  11  | async function slash(page: Page, label: string) {
  12  |   await page.keyboard.type('/');
  13  |   const menu = page.getByRole('listbox', { name: 'ブロックを挿入' });
  14  |   await expect(menu).toBeVisible();
  15  |   await menu.getByRole('option', { name: label, exact: label !== 'Toggle' }).click();
  16  |   await expect(menu).toHaveCount(0);
  17  | }
  18  | 
  19  | const blocks = [
  20  |   ['本文', 'p'], ['見出し1', 'h1'], ['見出し2', 'h2'], ['見出し3', 'h3'],
  21  |   ['箇条書き', 'ul:not([data-type])'], ['番号付きリスト', 'ol'],
  22  |   ['Todo', 'ul[data-type="taskList"]'], ['引用', 'blockquote'], ['コード', 'pre'],
  23  |   ['区切り線', 'hr'], ['Toggle', '[data-type="details"]'],
  24  | ] as const;
  25  | for (const [label, selector] of blocks) {
  26  |   test(`STEP2-BLOCK: slash inserts ${label}, edit and delete`, async ({ page }) => {
  27  |     const editor = await body(page);
  28  |     await slash(page, label);
  29  |     await expect(editor.locator(selector).first()).toBeVisible();
  30  |     if (label !== '区切り線') {
  31  |       await page.keyboard.type('block content');
  32  |       await expect(editor).toContainText('block content');
  33  |     }
  34  |     await editor.press('ControlOrMeta+a');
  35  |     await editor.press('Backspace');
  36  |     await expect(editor).not.toContainText('block content');
  37  |     if (selector !== 'p') await expect(editor.locator(selector)).toHaveCount(0);
  38  |   });
  39  | }
  40  | 
  41  | test('STEP2-TODO: checkbox and nested list survive undo/redo', async ({ page }) => {
  42  |   const editor = await body(page);
  43  |   await slash(page, 'Todo');
  44  |   await page.keyboard.type('first');
  45  |   await page.keyboard.press('Enter');
  46  |   await page.keyboard.type('second');
  47  |   await page.getByRole('button', { name: 'インデント', exact: true }).click();
  48  |   await expect(editor.locator('ul[data-type="taskList"] ul[data-type="taskList"]')).toHaveCount(1);
  49  |   await page.getByRole('button', { name: 'インデント解除', exact: true }).click();
  50  |   await expect(editor.locator('ul[data-type="taskList"] ul[data-type="taskList"]')).toHaveCount(0);
  51  |   const checkbox = editor.getByRole('checkbox', { name: 'Todo: first', exact: true });
  52  |   await checkbox.check();
  53  |   await expect(checkbox).toBeChecked();
  54  |   await page.getByRole('button', { name: '元に戻す', exact: true }).click();
  55  |   await expect(checkbox).not.toBeChecked();
  56  |   await page.getByRole('button', { name: 'やり直す', exact: true }).click();
  57  |   await expect(checkbox).toBeChecked();
  58  | });
  59  | 
  60  | test('STEP2-TOGGLE: nested content folds without losing text and unwraps', async ({ page }) => {
  61  |   const editor = await body(page);
  62  |   await slash(page, 'Toggle');
  63  |   await page.keyboard.type('summary');
  64  |   const content = editor.locator('[data-type="detailsContent"]').first();
  65  |   await expect(content).toBeVisible();
  66  |   await content.locator('p').click();
  67  |   await page.keyboard.type('nested text');
  68  |   await page.keyboard.press('Enter');
  69  |   await slash(page, 'Toggle');
  70  |   await page.keyboard.type('nested summary');
  71  |   await expect(editor.locator('[data-type="details"] [data-type="details"]')).toHaveCount(1);
  72  |   await editor.getByRole('button', { name: 'Toggleを閉じる', exact: true }).first().click();
  73  |   await expect(content).toBeHidden();
  74  |   await editor.getByRole('button', { name: 'Toggleを開く', exact: true }).first().click();
  75  |   await expect(content).toBeVisible();
  76  |   await expect(content).toContainText('nested text');
  77  |   await editor.locator('summary').first().click();
  78  |   await page.getByRole('button', { name: 'Toggleを解除', exact: true }).click();
  79  |   await expect(editor.locator(':scope > [data-type="details"]')).toHaveCount(1);
  80  |   await expect(editor).toContainText('nested text');
  81  | });
  82  | 
  83  | test('STEP2-MENTION: keyboard selects a fixed entity and Escape leaves ordinary text', async ({ page }) => {
  84  |   const editor = await body(page);
  85  |   await page.keyboard.type('@');
  86  |   await expect(page.getByRole('listbox', { name: 'Mention候補' })).toBeVisible();
  87  |   await page.keyboard.press('ArrowDown');
  88  |   await page.keyboard.press('Enter');
  89  |   await expect(editor.locator('[data-type="mention"]')).toHaveAttribute('data-id', 'demo-task');
  90  |   await expect(editor).toContainText('サンプルTask');
  91  |   await page.keyboard.type('@');
  92  |   await page.keyboard.press('Escape');
  93  |   await expect(page.getByRole('listbox')).toHaveCount(0);
  94  |   await expect(editor).toContainText('@');
  95  | });
  96  | 
  97  | for (const [text, selector] of [['# ', 'h1'], ['## ', 'h2'], ['### ', 'h3'], ['- ', 'ul:not([data-type])'], ['1. ', 'ol'], ['[] ', 'ul[data-type="taskList"]']] as const) {
  98  |   test(`STEP2-MARKDOWN: ${text} shortcut`, async ({ page }) => {
  99  |     const editor = await body(page);
  100 |     await page.keyboard.type(text);
  101 |     await expect(editor.locator(selector)).toHaveCount(1);
  102 |     await page.keyboard.type('shortcut content');
  103 |     await expect(editor.locator(selector)).toContainText('shortcut content');
  104 |   });
```