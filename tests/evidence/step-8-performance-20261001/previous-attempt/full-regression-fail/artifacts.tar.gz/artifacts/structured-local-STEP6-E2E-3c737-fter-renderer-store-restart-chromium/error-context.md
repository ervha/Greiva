# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: structured-local.spec.ts >> STEP6-E2E: Task and Relation pointer/keyboard CRUD persist with pending operations after renderer/store restart
- Location: tests/e2e/structured-local.spec.ts:3:1

# Error details

```
Error: page.goto: net::ERR_CONNECTION_REFUSED at http://127.0.0.1:1420/?page=01a0f6b7-2879-76d0-b8f8-7d7e545cddf5
Call log:
  - navigating to "http://127.0.0.1:1420/?page=01a0f6b7-2879-76d0-b8f8-7d7e545cddf5", waiting until "load"

```

# Test source

```ts
  1  | import { test,expect } from '@playwright/test';
  2  | import { newId } from '@greiva/shared';
  3  | test('STEP6-E2E: Task and Relation pointer/keyboard CRUD persist with pending operations after renderer/store restart', async ({page}) => {
  4  |   test.setTimeout(60_000);
> 5  |   const pageId = newId(); await page.goto(`/?page=${pageId}`);
     |                                      ^ Error: page.goto: net::ERR_CONNECTION_REFUSED at http://127.0.0.1:1420/?page=01a0f6b7-2879-76d0-b8f8-7d7e545cddf5
  6  |   const panel = page.getByRole('region',{name:'TaskとRelation'});
  7  |   await expect(panel.getByLabel('Taskの保存状態')).toContainText('送信待ち 0件');
  8  |   await page.getByRole('button',{name:'接続を一時停止'}).click();
  9  |   await panel.getByLabel('Taskの名前').fill('offline task');
  10 |   await panel.getByLabel('Taskの状態',{exact:true}).selectOption('in_progress');
  11 |   await panel.getByLabel('期限').fill('2028-02-29');
  12 |   await panel.getByLabel('Taskの名前').press('Enter');
  13 |   await expect(panel.getByLabel('Taskの保存状態')).toContainText('送信待ち 1件');
  14 |   await expect(panel.getByLabel('Taskの名前')).toBeFocused();
  15 |   await panel.getByRole('button',{name:'offline taskを編集'}).click();
  16 |   await panel.getByLabel('Taskの名前').fill('edited offline task');
  17 |   await panel.getByLabel('期限').fill('');
  18 |   await panel.getByRole('button',{name:'変更を保存',exact:true}).click();
  19 |   await expect(panel.getByLabel('保存したTask')).toContainText('edited offline task');
  20 |   await panel.getByRole('button',{name:'Relationを追加',exact:true}).click();
  21 |   await expect(panel.getByLabel('保存したRelation')).toContainText('edited offline task');
  22 |   await panel.getByRole('button',{name:'Relationを編集',exact:true}).click();
  23 |   await panel.getByLabel('関連元').selectOption({label:'Task: edited offline task'});
  24 |   await panel.getByRole('button',{name:'Relationの変更を保存'}).click();
  25 |   await expect(panel.getByLabel('Taskの保存状態')).toContainText('送信待ち 4件');
  26 |   await panel.screenshot({path:`${process.env.GREIVA_EVIDENCE_DIR ?? 'tests/evidence/runs/latest'}/structured-local.png`});
  27 |   const device = await page.evaluate(() => localStorage.getItem('greiva-test-device'));
  28 |   const before = await page.request.post('/__greiva_test_store',{data:{device,command:'structured-snapshot'}});
  29 |   const initial = (await before.json()).value;
  30 |   expect(initial.operations.map((operation:{status:string}) => operation.status)).toEqual(['pending','pending','pending','pending']);
  31 |   await page.request.post('/__greiva_test_store_control',{data:{device,command:'kill'}});
  32 |   await page.reload();
  33 |   await expect(panel.getByLabel('保存したTask')).toContainText('edited offline task');
  34 |   await expect(panel.getByLabel('Taskの保存状態')).toContainText('送信待ち 4件');
  35 |   const after = (await (await page.request.post('/__greiva_test_store',{data:{device,command:'structured-snapshot'}})).json()).value;
  36 |   expect(after).toEqual(initial);
  37 |   await panel.getByRole('button',{name:'edited offline taskを削除'}).click();
  38 |   await expect(panel.getByLabel('保存したTask').getByRole('listitem')).toHaveCount(0);
  39 |   await panel.getByRole('button',{name:'Relationを削除',exact:true}).click();
  40 |   await expect(panel.getByLabel('保存したRelation').getByRole('listitem')).toHaveCount(0);
  41 |   await expect(panel.getByLabel('Taskの保存状態')).toContainText('送信待ち 6件');
  42 |   const removed = (await (await page.request.post('/__greiva_test_store',{data:{device,command:'structured-snapshot'}})).json()).value;
  43 |   expect(removed.tasks[0].deletedAt).toMatch(/Z$/); expect(removed.relations[0].deletedAt).toMatch(/Z$/);
  44 | });
  45 | test('STEP6-WRITE-ERROR: failed queue commit retains the draft and permits a safe retry without duplicate Task',async ({page}) => {
  46 |   await page.goto(`/?page=${newId()}`);
  47 |   const panel = page.getByRole('region',{name:'TaskとRelation'});
  48 |   await expect(panel.getByLabel('Taskの保存状態')).toContainText('送信待ち 0件');
  49 |   await page.getByRole('button',{name:'接続を一時停止'}).click();
  50 |   const device = await page.evaluate(() => localStorage.getItem('greiva-test-device'));
  51 |   await page.request.post('/__greiva_test_store_control',{data:{device,command:'structured-write-failure'}});
  52 |   await panel.getByLabel('Taskの名前').fill('preserve this draft');
  53 |   await panel.getByRole('button',{name:'Taskを追加',exact:true}).click();
  54 |   await expect(panel.getByRole('alert')).toContainText('Injected structured queue failure');
  55 |   await expect(panel.getByLabel('Taskの名前')).toHaveValue('preserve this draft');
  56 |   await expect(panel.getByLabel('Taskの保存状態')).toContainText('送信待ち 0件');
  57 |   await expect(panel.getByLabel('保存したTask').getByRole('listitem')).toHaveCount(0);
  58 |   await page.request.post('/__greiva_test_store_control',{data:{device,command:'clear-structured-write-failure'}});
  59 |   await panel.getByRole('button',{name:'Taskを追加',exact:true}).click();
  60 |   await expect(panel.getByLabel('Taskの保存状態')).toContainText('送信待ち 1件');
  61 |   await expect(panel.getByRole('alert')).toHaveCount(0);
  62 |   await expect(panel.getByLabel('保存したTask').getByRole('listitem')).toHaveCount(1);
  63 | });
  64 | 
```