# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: persistence.spec.ts >> STEP5-RESTORE-schema: incompatible or corrupted SQLite fails closed
- Location: tests/e2e/persistence.spec.ts:107:3

# Error details

```
Error: apiRequestContext.post: socket hang up
Call log:
  - → POST http://127.0.0.1:1420/__greiva_test_store_control
    - user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.8010.12 Safari/537.36
    - accept: */*
    - accept-encoding: gzip,deflate,br
    - content-type: application/json
    - content-length: 66

```

# Page snapshot

```yaml
- main [ref=e3]:
  - generic [ref=e4]:
    - heading "Greiva PoC" [level=1] [ref=e5]
    - generic [ref=e6]:
      - text: 本文
      - status "同期状態" [ref=e7]: サーバーと同期済み
  - paragraph [ref=e8]: 本文とタイトルを端末のSQLiteへ保存します。タイトルは端末内のみで、他の端末とは同期しません。
  - status "端末の保存状態" [ref=e9]: 端末に保存済み
  - paragraph [ref=e10]: 保存中の入力は、強制終了すると失われることがあります。端末に保存済みの変更は、同期前でも保持されます。
  - generic [ref=e11]:
    - generic [ref=e12]:
      - text: 保存したPage
      - combobox "保存したPage" [ref=e13]:
        - option "無題のPage (9ee63e)" [selected]
    - button "新しいPage" [ref=e14] [cursor=pointer]
    - link "同じPageを別画面で開く" [ref=e15] [cursor=pointer]:
      - /url: /?page=01a0f6b7-063b-71c5-9f2d-0369b39ee63e
    - button "接続を一時停止" [ref=e16] [cursor=pointer]
  - region "Page Editor" [ref=e17]:
    - textbox "Pageタイトル" [ref=e18]:
      - /placeholder: 無題のPage
    - toolbar "編集操作" [ref=e19]:
      - button "元に戻す" [disabled] [ref=e20]
      - button "やり直す" [disabled] [ref=e21]
      - group [ref=e22]:
        - generic "ブロックを挿入" [ref=e23] [cursor=pointer]
      - button "上へ移動" [disabled] [ref=e24]
      - button "下へ移動" [disabled] [ref=e25]
      - button "インデント" [disabled] [ref=e26]
      - button "インデント解除" [disabled] [ref=e27]
    - paragraph [ref=e28]: 行頭の / でブロック追加、@ でMention。トグルは Enter で本文へ、Ctrl+Enter で開閉。
    - textbox "Page本文" [ref=e30]:
      - button "ブロック1をドラッグして移動" [ref=e31]: ⠿
      - paragraph [ref=e32]: 「/」でブロックを追加
  - region "TaskとRelation" [ref=e33]:
    - heading "TaskとRelation" [level=2] [ref=e34]
    - paragraph [ref=e35]: TaskとRelationを端末へ保存し、接続中はサーバーへ同期します。
    - status "Taskの保存状態" [ref=e36]: Taskを読み込み中…
    - generic [ref=e37]:
      - status "TaskとRelationの同期状態" [ref=e38]: 保存・受信のエラー
      - generic [ref=e39]: "Error: Structured storage: TypeError: Failed to fetch"
      - button "Taskの同期を再試行" [ref=e40] [cursor=pointer]
    - form "Taskを登録・編集" [ref=e41]:
      - generic [ref=e42]:
        - text: Taskの名前
        - textbox "Taskの名前" [disabled] [ref=e43]
      - generic [ref=e44]:
        - text: 状態
        - combobox "Taskの状態" [disabled] [ref=e45]:
          - option "未着手" [selected]
          - option "進行中"
          - option "完了"
      - generic [ref=e46]:
        - text: 期限
        - textbox "期限" [disabled] [ref=e47]
      - button "Taskを追加" [disabled] [ref=e48]
    - list "保存したTask"
    - heading "Relation" [level=3] [ref=e49]
    - form "Relationを登録・編集" [ref=e50]:
      - generic [ref=e51]:
        - text: 関連元
        - combobox "関連元" [ref=e52]:
          - 'option "Page: 無題" [selected]'
      - generic [ref=e53]:
        - text: 関連先
        - combobox "関連先" [ref=e54]:
          - 'option "Page: 無題" [selected]'
      - button "Relationを追加" [disabled] [ref=e55]
    - list "保存したRelation"
    - region "競合一覧" [ref=e56]:
      - heading "競合 0件" [level=3] [ref=e57]
      - paragraph [ref=e58]: 未解決の競合はありません。
```

# Test source

```ts
  1   | import { test, expect, chromium, type BrowserContext, type Page } from '@playwright/test';
  2   | import { mkdtempSync, rmSync } from 'node:fs';
  3   | import { tmpdir } from 'node:os';
  4   | import { join } from 'node:path';
  5   | import { newId } from '@greiva/shared';
  6   | 
  7   | const body = (page: Page) => page.getByRole('textbox', { name: 'Page本文' });
  8   | const saved = (page: Page) => expect(page.getByLabel('端末の保存状態')).toHaveText('端末に保存済み');
  9   | async function snapshot(page: Page) {
  10  |   return page.evaluate(() => (window as unknown as { greivaTest: { snapshot: () => { clocks: number[][]; json: unknown; fragment: string; pending: number; selection: { from: number; to: number; parent: string; offset: number; size: number } } } }).greivaTest.snapshot());
  11  | }
  12  | async function device(page: Page) { return page.evaluate(() => localStorage.getItem('greiva-test-device')); }
  13  | async function control(page: Page, command: string) {
> 14  |   const response = await page.request.post('/__greiva_test_store_control', { data: { device: await device(page), command } });
      |                                       ^ Error: apiRequestContext.post: socket hang up
  15  |   expect(response.ok()).toBe(true); return response.json();
  16  | }
  17  | async function profile(path: string, offline: boolean, stableDevice: string) {
  18  |   const context = await chromium.launchPersistentContext(path, { baseURL: 'http://127.0.0.1:1420' });
  19  |   // Native Tauri selects a fixed app-config path, independent of WebView cache.
  20  |   // Chromium localStorage itself is not a durable device identity after SIGKILL.
  21  |   await context.addInitScript(device => localStorage.setItem('greiva-test-device', device), stableDevice);
  22  |   if (offline) await context.routeWebSocket(/127\.0\.0\.1:1234/, socket => socket.close());
  23  |   return context;
  24  | }
  25  | async function killBrowser(context: BrowserContext) {
  26  |   const browser = context.browser()!;
  27  |   const cdp = await browser.newBrowserCDPSession();
  28  |   const result = await cdp.send('SystemInfo.getProcessInfo');
  29  |   const processInfo = result.processInfo.find(value => value.type === 'browser')!;
  30  |   const disconnected = new Promise<void>(done => browser.once('disconnected', () => done()));
  31  |   process.kill(processInfo.id, 'SIGKILL'); await disconnected;
  32  |   return { browserPid: processInfo.id, signal: 'SIGKILL', at: new Date().toISOString() };
  33  | }
  34  | 
  35  | test('STEP5-CRASH: new offline Page metadata and block edits survive renderer/store SIGKILL, reopen offline and converge', async ({ browser }, info) => {
  36  |   test.setTimeout(60000);
  37  |   const directory = mkdtempSync(join(tmpdir(), 'greiva-page-crash-'));
  38  |   const stableDevice = newId();
  39  |   let context: BrowserContext | undefined;
  40  |   const peerContext = await browser.newContext();
  41  |   try {
  42  |     context = await profile(directory, true, stableDevice);
  43  |     let a = context.pages()[0]!;
  44  |     await a.goto('/'); await expect(body(a)).toBeVisible();
  45  |     await a.getByRole('button', { name: '新しいPage', exact: true }).click();
  46  |     await expect(body(a)).toBeVisible();
  47  |     const url = a.url();
  48  |     expect(new URL(url).searchParams.get('page')).toMatch(/^[0-9a-f-]{14}7/);
  49  |     await a.getByLabel('Pageタイトル', { exact: true }).fill('オフラインのPage');
  50  |     await body(a).click(); await a.keyboard.type('keep');
  51  |     await a.keyboard.press('Enter'); await a.keyboard.type('remove');
  52  |     await a.keyboard.press('Enter'); await a.keyboard.type('move');
  53  |     await body(a).locator(':scope > p').nth(1).click();
  54  |     await expect.poll(async () => (await snapshot(a)).selection.parent).toBe('remove');
  55  |     await a.keyboard.press('Home');
  56  |     await expect.poll(async () => (await snapshot(a)).selection.offset).toBe(0);
  57  |     await a.keyboard.press('Shift+End');
  58  |     await expect.poll(async () => { const { selection } = await snapshot(a); return selection.to - selection.from; }).toBe('remove'.length);
  59  |     await info.attach('before-delete-selection', { body: JSON.stringify(await snapshot(a)), contentType: 'application/json' });
  60  |     await a.keyboard.press('Backspace'); await a.keyboard.press('Delete');
  61  |     await body(a).locator(':scope > p:last-child').click();
  62  |     await expect.poll(async () => (await snapshot(a)).selection.parent).toBe('move');
  63  |     await a.getByRole('button', { name: '上へ移動', exact: true }).click();
  64  |     await expect(body(a)).not.toContainText('remove');
  65  |     await saved(a);
  66  |     const before = await snapshot(a);
  67  |     const storedResponse = await a.request.post('/__greiva_test_store', { data: { device: stableDevice, command: 'load', pageId: new URL(url).searchParams.get('page') } });
  68  |     const storedBefore = (await storedResponse.json()).value;
  69  |     expect(storedBefore.metadata.title).toBe('オフラインのPage');
  70  |     const storeKill = await control(a, 'kill');
  71  |     const browserKill = await killBrowser(context); context = undefined;
  72  |     context = await profile(directory, true, stableDevice); a = context.pages()[0]!;
  73  |     await a.goto('/'); await expect(body(a)).toBeVisible(); await saved(a);
  74  |     await expect(a.getByLabel('Pageタイトル', { exact: true })).toHaveValue('オフラインのPage');
  75  |     await expect(a.getByRole('link', { name: '同じPageを別画面で開く' })).toHaveAttribute('href', `/?page=${new URL(url).searchParams.get('page')}`);
  76  |     const restored = await snapshot(a);
  77  |     expect(restored.clocks).toEqual(before.clocks); expect(restored.json).toEqual(before.json); expect(restored.fragment).toEqual(before.fragment);
  78  |     await info.attach('offline-crash', { body: JSON.stringify({ stableDevice, storedBefore, before, restored, storeKill, browserKill }, null, 2), contentType: 'application/json' });
  79  |     await context.close(); context = await profile(directory, false, stableDevice); a = context.pages()[0]!;
  80  |     const b = await peerContext.newPage();
  81  |     await Promise.all([a.goto('/'), b.goto(url)]);
  82  |     for (const page of [a, b]) { await expect(body(page)).toBeVisible(); await saved(page); await expect(page.getByLabel('同期状態', { exact: true })).toHaveText('サーバーと同期済み'); }
  83  |     await expect.poll(async () => { const [x, y] = await Promise.all([snapshot(a), snapshot(b)]); return JSON.stringify(x.clocks) === JSON.stringify(y.clocks) && JSON.stringify(x.json) === JSON.stringify(y.json) && x.fragment === y.fragment; }).toBe(true);
  84  |     await expect(body(b)).toContainText('keep'); await expect(body(b)).toContainText('move');
  85  |     await expect(b.getByLabel('Pageタイトル', { exact: true })).toHaveValue(''); // Metadata stays device-local in Step 5.
  86  |     await info.attach('restart-convergence', { body: JSON.stringify(await Promise.all([snapshot(a), snapshot(b)]), null, 2), contentType: 'application/json' });
  87  |   } finally { await context?.close(); await peerContext.close(); rmSync(directory, { recursive: true, force: true }); }
  88  | });
  89  | 
  90  | test('STEP5-WRITE-ERROR: failed SQLite commit never sends the unsafe update or reports saved/synced', async ({ page, browser }, info) => {
  91  |   const peer = await browser.newContext();
  92  |   try {
  93  |     const url = `/?page=${newId()}`; const b = await peer.newPage();
  94  |     await Promise.all([page.goto(url), b.goto(url)]);
  95  |     for (const view of [page, b]) { await expect(body(view)).toBeVisible(); await saved(view); await expect(view.getByLabel('同期状態', { exact: true })).toHaveText('サーバーと同期済み'); }
  96  |     await control(page, 'write-failure'); await body(page).click(); await page.keyboard.type('unsafe');
  97  |     await expect(page.getByLabel('同期状態', { exact: true })).toHaveText('端末への保存エラー');
  98  |     await expect(page.getByLabel('端末の保存状態')).toContainText('保存できません');
  99  |     await expect(page.getByRole('alert')).toContainText('Injected SQLite write failure');
  100 |     await expect(body(b)).not.toContainText('unsafe');
  101 |     await page.waitForTimeout(500); await expect(body(b)).not.toContainText('unsafe');
  102 |     await info.attach('write-failure', { body: JSON.stringify({ local: await snapshot(page), remote: await snapshot(b) }, null, 2), contentType: 'application/json' });
  103 |   } finally { await peer.close(); }
  104 | });
  105 | 
  106 | for (const fault of ['corrupt', 'schema'] as const) {
  107 |   test(`STEP5-RESTORE-${fault}: incompatible or corrupted SQLite fails closed`, async ({ page }) => {
  108 |     await page.goto(`/?page=${newId()}`); await expect(body(page)).toBeVisible(); await saved(page);
  109 |     await control(page, 'kill'); await control(page, fault);
  110 |     await page.reload();
  111 |     await expect(page.getByLabel('同期状態', { exact: true })).toHaveText('端末への保存エラー');
  112 |     await expect(page.getByRole('alert')).toContainText(fault === 'schema' ? 'Unsupported local schema version' : 'checksum mismatch');
  113 |     await expect(body(page)).not.toBeVisible();
  114 |   });
```