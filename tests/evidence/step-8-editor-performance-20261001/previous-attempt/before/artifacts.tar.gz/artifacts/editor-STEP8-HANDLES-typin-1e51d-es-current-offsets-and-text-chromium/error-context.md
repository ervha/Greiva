# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: editor.spec.ts >> STEP8-HANDLES: typing retains handle DOM and dragging uses current offsets and text
- Location: tests/e2e/editor.spec.ts:127:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- main [ref=e3]:
  - generic [ref=e4]:
    - heading "Greiva PoC" [level=1] [ref=e5]
    - generic [ref=e6]:
      - text: 本文
      - status "同期状態" [ref=e7]: サーバーと同期済み
  - paragraph [ref=e8]: 本文とタイトルを端末のSQLiteへ保存します。タイトルは端末内のみで、他の端末とは同期しません。
  - status "端末の保存状態" [ref=e9]: 端末に保存済み
  - paragraph [ref=e10]: 保存中の入力は、強制終了すると失われることがあります。端末に保存済みの変更は、同期前でも保持されます。
  - generic [ref=e11]:
    - generic [ref=e12]:
      - text: 保存したPage
      - combobox "保存したPage" [ref=e13]:
        - option "無題のPage (a53bff)" [selected]
    - button "新しいPage" [ref=e14] [cursor=pointer]
    - link "同じPageを別画面で開く" [ref=e15] [cursor=pointer]:
      - /url: /?page=8e9563e5-eddb-4454-90a1-9940e3a53bff
    - button "接続を一時停止" [ref=e16] [cursor=pointer]
  - region "Page Editor" [ref=e17]:
    - textbox "Pageタイトル" [ref=e18]:
      - /placeholder: 無題のPage
    - toolbar "編集操作" [ref=e19]:
      - button "元に戻す" [ref=e20] [cursor=pointer]
      - button "やり直す" [disabled] [ref=e21]
      - group [ref=e22]:
        - generic "ブロックを挿入" [ref=e23] [cursor=pointer]
      - button "上へ移動" [ref=e24] [cursor=pointer]
      - button "下へ移動" [disabled] [ref=e25]
      - button "インデント" [disabled] [ref=e26]
      - button "インデント解除" [disabled] [ref=e27]
    - paragraph [ref=e28]: 行頭の / でブロック追加、@ でMention。トグルは Enter で本文へ、Ctrl+Enter で開閉。
    - textbox "Page本文" [active] [ref=e30]:
      - button "ブロック1をドラッグして移動" [ref=e31]: ⠿
      - paragraph [ref=e32]: first shifted
      - button "ブロック2をドラッグして移動" [ref=e33]: ⠿
      - paragraph [ref=e34]: second
      - button "ブロック3をドラッグして移動" [ref=e35]: ⠿
      - paragraph [ref=e36]: third edited
  - region "TaskとRelation" [ref=e37]:
    - heading "TaskとRelation" [level=2] [ref=e38]
    - paragraph [ref=e39]: TaskとRelationを端末へ保存し、接続中はサーバーへ同期します。
    - status "Taskの保存状態" [ref=e40]: 端末に保存済み・送信待ち 0件
    - generic [ref=e41]:
      - status "TaskとRelationの同期状態" [ref=e42]: 再試行待ち
      - generic [ref=e43]: "Structured pull: HTTP 503"
      - button "Taskの同期を再試行" [ref=e44] [cursor=pointer]
    - form "Taskを登録・編集" [ref=e45]:
      - generic [ref=e46]:
        - text: Taskの名前
        - textbox "Taskの名前" [ref=e47]
      - generic [ref=e48]:
        - text: 状態
        - combobox "Taskの状態" [ref=e49]:
          - option "未着手" [selected]
          - option "進行中"
          - option "完了"
      - generic [ref=e50]:
        - text: 期限
        - textbox "期限" [ref=e51]
      - button "Taskを追加" [ref=e52] [cursor=pointer]
    - list "保存したTask"
    - heading "Relation" [level=3] [ref=e53]
    - form "Relationを登録・編集" [ref=e54]:
      - generic [ref=e55]:
        - text: 関連元
        - combobox "関連元" [ref=e56]:
          - 'option "Page: 無題" [selected]'
      - generic [ref=e57]:
        - text: 関連先
        - combobox "関連先" [ref=e58]:
          - 'option "Page: 無題" [selected]'
      - button "Relationを追加" [disabled] [ref=e59]
    - list "保存したRelation"
    - region "競合一覧" [ref=e60]:
      - heading "競合 0件" [level=3] [ref=e61]
      - paragraph [ref=e62]: 未解決の競合はありません。
```

# Test source

```ts
  41  | test('STEP2-TODO: checkbox and nested list survive undo/redo', async ({ page }) => {
  42  |   const editor = await body(page);
  43  |   await slash(page, 'Todo');
  44  |   await page.keyboard.type('first');
  45  |   await page.keyboard.press('Enter');
  46  |   await page.keyboard.type('second');
  47  |   await page.getByRole('button', { name: 'インデント', exact: true }).click();
  48  |   await expect(editor.locator('ul[data-type="taskList"] ul[data-type="taskList"]')).toHaveCount(1);
  49  |   await page.getByRole('button', { name: 'インデント解除', exact: true }).click();
  50  |   await expect(editor.locator('ul[data-type="taskList"] ul[data-type="taskList"]')).toHaveCount(0);
  51  |   const checkbox = editor.getByRole('checkbox', { name: 'Todo: first', exact: true });
  52  |   await checkbox.check();
  53  |   await expect(checkbox).toBeChecked();
  54  |   await page.getByRole('button', { name: '元に戻す', exact: true }).click();
  55  |   await expect(checkbox).not.toBeChecked();
  56  |   await page.getByRole('button', { name: 'やり直す', exact: true }).click();
  57  |   await expect(checkbox).toBeChecked();
  58  | });
  59  | 
  60  | test('STEP2-TOGGLE: nested content folds without losing text and unwraps', async ({ page }) => {
  61  |   const editor = await body(page);
  62  |   await slash(page, 'Toggle');
  63  |   await page.keyboard.type('summary');
  64  |   const content = editor.locator('[data-type="detailsContent"]').first();
  65  |   await expect(content).toBeVisible();
  66  |   await content.locator('p').click();
  67  |   await page.keyboard.type('nested text');
  68  |   await page.keyboard.press('Enter');
  69  |   await slash(page, 'Toggle');
  70  |   await page.keyboard.type('nested summary');
  71  |   await expect(editor.locator('[data-type="details"] [data-type="details"]')).toHaveCount(1);
  72  |   await editor.getByRole('button', { name: 'Toggleを閉じる', exact: true }).first().click();
  73  |   await expect(content).toBeHidden();
  74  |   await editor.getByRole('button', { name: 'Toggleを開く', exact: true }).first().click();
  75  |   await expect(content).toBeVisible();
  76  |   await expect(content).toContainText('nested text');
  77  |   await editor.locator('summary').first().click();
  78  |   await page.getByRole('button', { name: 'Toggleを解除', exact: true }).click();
  79  |   await expect(editor.locator(':scope > [data-type="details"]')).toHaveCount(1);
  80  |   await expect(editor).toContainText('nested text');
  81  | });
  82  | 
  83  | test('STEP2-MENTION: keyboard selects a fixed entity and Escape leaves ordinary text', async ({ page }) => {
  84  |   const editor = await body(page);
  85  |   await page.keyboard.type('@');
  86  |   await expect(page.getByRole('listbox', { name: 'Mention候補' })).toBeVisible();
  87  |   await page.keyboard.press('ArrowDown');
  88  |   await page.keyboard.press('Enter');
  89  |   await expect(editor.locator('[data-type="mention"]')).toHaveAttribute('data-id', 'demo-task');
  90  |   await expect(editor).toContainText('サンプルTask');
  91  |   await page.keyboard.type('@');
  92  |   await page.keyboard.press('Escape');
  93  |   await expect(page.getByRole('listbox')).toHaveCount(0);
  94  |   await expect(editor).toContainText('@');
  95  | });
  96  | 
  97  | for (const [text, selector] of [['# ', 'h1'], ['## ', 'h2'], ['### ', 'h3'], ['- ', 'ul:not([data-type])'], ['1. ', 'ol'], ['[] ', 'ul[data-type="taskList"]']] as const) {
  98  |   test(`STEP2-MARKDOWN: ${text} shortcut`, async ({ page }) => {
  99  |     const editor = await body(page);
  100 |     await page.keyboard.type(text);
  101 |     await expect(editor.locator(selector)).toHaveCount(1);
  102 |     await page.keyboard.type('shortcut content');
  103 |     await expect(editor.locator(selector)).toContainText('shortcut content');
  104 |   });
  105 | }
  106 | 
  107 | test('STEP2-MOVE: drag changes order, undo restores it, keyboard moves the block', async ({ page }) => {
  108 |   const editor = await body(page);
  109 |   await page.keyboard.type('first');
  110 |   await page.keyboard.press('Enter');
  111 |   await page.keyboard.type('second');
  112 |   await page.keyboard.press('Enter');
  113 |   await page.keyboard.type('third');
  114 |   const texts = () => editor.locator(':scope > p').allTextContents();
  115 |   await expect.poll(texts).toEqual(['first', 'second', 'third']);
  116 |   await editor.getByRole('button', { name: 'ブロック3をドラッグして移動', exact: true }).dragTo(editor.locator(':scope > p').first(), { targetPosition: { x: 5, y: 2 } });
  117 |   await expect.poll(texts).toEqual(['third', 'first', 'second']);
  118 |   await page.getByRole('button', { name: '元に戻す', exact: true }).click();
  119 |   await expect.poll(texts).toEqual(['first', 'second', 'third']);
  120 |   await editor.locator(':scope > p').last().click();
  121 |   await page.keyboard.press('ControlOrMeta+Shift+ArrowUp');
  122 |   await expect.poll(texts).toEqual(['first', 'third', 'second']);
  123 |   await page.getByRole('button', { name: '下へ移動', exact: true }).click();
  124 |   await expect.poll(texts).toEqual(['first', 'second', 'third']);
  125 | });
  126 | 
  127 | test('STEP8-HANDLES: typing retains handle DOM and dragging uses current offsets and text', async ({ page }) => {
  128 |   const editor = await body(page);
  129 |   await page.keyboard.type('first');await page.keyboard.press('Enter');
  130 |   await page.keyboard.type('second');await page.keyboard.press('Enter');await page.keyboard.type('third');
  131 |   await expect(editor.locator('.block-handle-anchor')).toHaveCount(3);
  132 |   await editor.evaluate(element => {
  133 |     (window as unknown as {greivaHandles:Element[]}).greivaHandles=Array.from(element.querySelectorAll('.block-handle-anchor'));
  134 |   });
  135 |   await editor.locator(':scope > p').first().click();await page.keyboard.press('End');await page.keyboard.type(' shifted');
  136 |   await editor.locator(':scope > p').last().click();await page.keyboard.press('End');await page.keyboard.type(' edited');
  137 |   await expect(editor).toBeFocused();
  138 |   expect(await editor.evaluate(element => {
  139 |     const before=(window as unknown as {greivaHandles:Element[]}).greivaHandles;
  140 |     return Array.from(element.querySelectorAll('.block-handle-anchor')).every((node,index)=>node===before[index]);
> 141 |   })).toBe(true);
      |       ^ Error: expect(received).toBe(expected) // Object.is equality
  142 |   const texts=()=>editor.locator(':scope > p').allTextContents();
  143 |   await expect.poll(texts).toEqual(['first shifted','second','third edited']);
  144 |   const transfer=await page.evaluateHandle(()=>new DataTransfer());
  145 |   const handle=editor.getByRole('button',{name:'ブロック3をドラッグして移動',exact:true});
  146 |   await handle.dispatchEvent('dragstart',{dataTransfer:transfer});
  147 |   expect(await transfer.evaluate(value=>value.getData('text/plain'))).toBe('third edited');
  148 |   await handle.dispatchEvent('dragend');await transfer.dispose();
  149 |   // Real pointer drag verifies the reused getPos after both offset and payload changed.
  150 |   await handle.dragTo(editor.locator(':scope > p').first(),{targetPosition:{x:5,y:2}});
  151 |   await expect.poll(texts).toEqual(['third edited','first shifted','second']);
  152 |   await page.getByRole('button',{name:'元に戻す',exact:true}).click();
  153 |   await expect.poll(texts).toEqual(['first shifted','second','third edited']);
  154 |   await page.getByRole('button',{name:'やり直す',exact:true}).click();
  155 |   await expect.poll(texts).toEqual(['third edited','first shifted','second']);
  156 |   await expect(editor.getByRole('button',{name:'ブロック3をドラッグして移動',exact:true})).toHaveCount(1);
  157 | });
  158 | 
  159 | test('STEP2-COMPOSITION: slash menu does not consume composition Enter', async ({ page }) => {
  160 |   const editor = await body(page);
  161 |   await page.keyboard.type('/');
  162 |   const menu = page.getByRole('listbox', { name: 'ブロックを挿入' });
  163 |   await expect(menu).toBeVisible();
  164 |   const consumed = await editor.evaluate(element => !element.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', isComposing: true, bubbles: true, cancelable: true })));
  165 |   expect(consumed).toBe(false);
  166 |   await expect(menu).toBeVisible();
  167 |   await page.keyboard.press('Escape');
  168 |   await expect(menu).toHaveCount(0);
  169 |   // Synthetic composition safety check only; this is not Microsoft IME evidence.
  170 | });
  171 | 
```